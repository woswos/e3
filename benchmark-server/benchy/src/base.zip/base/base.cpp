#include "base.h"
#include <iostream>
#include <map>
#include <time.h>
#include <random>
#include <functional>
#include <chrono>

void Benchmark::init(){

}

void Benchmark::generateKeySet(){

}


void Benchmark::consoleLog(string message){
    std::cout << message;
}

void Benchmark::consoleLogln(string message){
    std::cout << message << std::endl;
}

void Benchmark::consoleErrorLog(string message){
    std::cout << "######" << std::endl;
    std::cout << "ERROR:" << std::endl;
    std::cout << message << std::endl;
    std::cout << "######" << std::endl << std::endl;
}

void Benchmark::addTiming(string key, long long value){
    if ( Benchmark::timings.find(key) == Benchmark::timings.end() ) {
        Benchmark::timings.insert({key, value});

    } else {
        long long temp = Benchmark::timings[key];
        Benchmark::timings[key] = ((value + temp)/2);

    }
}


long long Benchmark::getTiming(string key){

    return Benchmark::timings[key];
}


void Benchmark::startTimer(){

    Benchmark::tempTime = std::chrono::high_resolution_clock::now();;
}


long long Benchmark::stopTimer(){

    std::chrono::_V2::system_clock::time_point currentTime = std::chrono::high_resolution_clock::now();

    return std::chrono::duration_cast<std::chrono::nanoseconds>(currentTime - Benchmark::tempTime).count();
}


bool Benchmark::randomBool() {
    static auto gen = std::bind(std::uniform_int_distribution<>(0,1),std::default_random_engine());
    return gen();
}

bool Benchmark::compare(int valueA, int valueB) {
    if(valueA == valueB){
        return true;
    } else {
        return false;
    }
}
