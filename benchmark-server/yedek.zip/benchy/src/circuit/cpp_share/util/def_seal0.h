#pragma once

// this header def_seal0.h should not be included in any code except *seal0.cpp

#include "def_seal.h"

struct SealCiphertext { bool b; };
