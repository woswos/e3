#pragma once

// this header def_heli0.h should not be included in any code except *heli0.cpp

#include "def_heli.h"

struct HeliCtxt { bool b; };

struct NativeProperties {};
