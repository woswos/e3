#pragma once

// this header def_tfhe0.h should not be included in any code except *tfhe0.cpp

#include "def_tfhe.h"

struct LweSample { bool b; };

