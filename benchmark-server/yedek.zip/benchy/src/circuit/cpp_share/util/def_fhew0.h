#pragma once

// this header def_fhew0.h should not be included in any code except *fhew0.cpp

#include "def_fhew.h"

struct LweCipherText { bool b; };
